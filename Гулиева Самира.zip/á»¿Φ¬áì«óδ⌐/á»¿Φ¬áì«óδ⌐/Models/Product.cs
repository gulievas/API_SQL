﻿using System;
using System.Collections.Generic;

namespace апишкаНовый.Models
{
    public partial class Product
    {
        public Product()
        {
            Recipes = new HashSet<Recipe>();
        }

        public int ProductId { get; set; }
        public string Name { get; set; } = null!;
        public int Quantity { get; set; }
        public int UserId { get; set; }

        public virtual Uuser User { get; set; } = null!;
        public virtual ICollection<Recipe> Recipes { get; set; }
    }
}
