﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using апишкаНовый.Models;

namespace Reciepe
{
    [Route("api/[controller]")]
    [ApiController]
    public class RecipesController : ControllerBase
    {
        private readonly Гулиева_APIContext _context;

        public RecipesController(Гулиева_APIContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            List<Recipe> recipes = _context.Recipes.ToList();
            return Ok(recipes);
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            Recipe recipe = _context.Recipes.Find(id);

            if (recipe == null)
            {
                return NotFound("Recipe not found");
            }

            return Ok(recipe);
        }

        [HttpPost]
        public IActionResult Add(Recipe recipe)
        {
            _context.Recipes.Add(recipe);
            _context.SaveChanges();

            return CreatedAtAction(nameof(GetById), new { RecipeId = recipe.RecipeId }, recipe);
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, Recipe recipe)
        {
            if (id != recipe.RecipeId)
            {
                return BadRequest("Invalid recipe ID");
            }

            _context.Entry(recipe).State = EntityState.Modified;
            _context.SaveChanges();

            return Ok(recipe);
        }


        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            Recipe recipe = _context.Recipes.Find(id);

            if (recipe == null)
            {
                return NotFound("Recipe not found");
            }

            _context.Recipes.Remove(recipe);
            _context.SaveChanges();

            return Ok(recipe);
        }
    }

}
