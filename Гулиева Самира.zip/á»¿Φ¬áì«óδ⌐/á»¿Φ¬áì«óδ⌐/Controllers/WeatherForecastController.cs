using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;

namespace апишкаНовый.Controllers
{
    public class Recipe
    {
        public string Name { get; set; }

        public List<string> Ingredients { get; set; }
    }

    [ApiController]
    [Route("[controller]")]
    public class RecipeController : ControllerBase
    {
        private static List<string> AvailableIngredients = new List<string>();
        private static List<Recipe> Recipes = new List<Recipe>();

        [HttpGet("ingredients")]
        public IActionResult GetIngredients()
        {
            return Ok(AvailableIngredients);
        }

        [HttpPost("ingredients")]
        public IActionResult AddIngredient(string ingredient)
        {
            if (string.IsNullOrEmpty(ingredient))
            {
                return BadRequest("Ингредиент не может быть пустым!");
            }

            AvailableIngredients.Add(ingredient);
            return Ok();
        }

        [HttpGet("recipes")]
        public IActionResult GetRecipes()
        {
            return Ok(Recipes);
        }

        [HttpPost("recipes")]
        public IActionResult AddRecipe(Recipe recipe)
        {
            if (recipe == null || string.IsNullOrEmpty(recipe.Name) || recipe.Ingredients == null || recipe.Ingredients.Count == 0)
            {
                return BadRequest("Рецепт не может быть пустым!");
            }

            Recipes.Add(recipe);
            return Ok();
        }

        [HttpGet("suggest-recipes")]
        public IActionResult GetSuggestedRecipes()
        {
            if (AvailableIngredients.Count == 0)
            {
                return BadRequest("Добавьте ингредиенты, чтобы получить предложения по рецептам.");
            }

            var suggestedRecipes = Recipes
                .Where(recipe => recipe.Ingredients.Any(ingredient => AvailableIngredients.Contains(ingredient)))
                .Select(recipe => recipe.Name);

            return Ok(suggestedRecipes);
        }
    }
}